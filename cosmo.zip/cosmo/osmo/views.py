from django.shortcuts import render
import requests
from .models import *
from django.shortcuts import render, HttpResponse,HttpResponseRedirect, reverse, get_object_or_404
from django.http import HttpResponseBadRequest
from django.template import loader
from django.urls import reverse
from django.shortcuts import render, redirect #new
from .forms import * #new
from django.contrib.auth.decorators import login_required
from django.views import View
from decimal import Decimal
from django.db.models import Sum, Count
from django.utils import timezone
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet
# Create your views here.

def login(requests):
  template = loader.get_template('account/login.html')
  return HttpResponse(template.render())

def adminpanel(requests):
  template = loader.get_template('blog/adminpanel.html')
  return HttpResponse(template.render())


def plan(request):
    plan = Plan.objects.all()
    template = loader.get_template('blog/plan.html')
    context = {
        'plan' : plan,
    }
    return HttpResponse(template.render(context, request))

def planlist(request):
    plan = Plan.objects.all()
    template = loader.get_template('blog/planslist.html')
    context = {
        'plan' : plan,
    }
    return HttpResponse(template.render(context, request))

def reserva(request,id):
    reservation = Plan.objects.get(id=id)
    template = loader.get_template('blog/reservation.html')
    context = {
        'plan' : reservation,
    }
    return HttpResponse(template.render(context, request))

def ddplan(request):
    plan = Plan.objects.all()
    template = loader.get_template('addplan.html')
    context = {
        'plan' : plan,
    }
    return HttpResponse(template.render(context, request)) 

def addplan(request):
  if request.method == 'POST':
    img = request.POST.get('img')
    price = request.POST.get('price')
    description = request.POST.get('description')
    if not img.strip():
        return render(request, 'blog/addplan.html')

    plan = Plan(img=img, price=price, description=description)
    plan.save()
    return HttpResponseRedirect(reverse('plan'))
  
  else: 
        return render(request, 'blog/addplan.html')
  

def upload_image(request): #new
    if request.method == 'POST':
        form = PlanForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
        return redirect(plan)
    else:
        form = PlanForm()
        context = {
            'form': form
        }
    return render(request, 'upload.html', context)

def update(request, id):
  plan = Plan.objects.get(id=id)
  template = loader.get_template('blog/planslist.html')
  context = {
    'plan' : plan,
  }
  return HttpResponse(template.render(context, request))

def update_plan(request, plan_id):
    plan = get_object_or_404(Plan, pk=plan_id)

    if request.method == 'POST':
        form = PlanForm(request.POST, request.FILES, instance=plan)

        if form.is_valid():
            form.save()
            return redirect('planlist')
    else:
        form = PlanForm(instance=plan)

    return render(request, 'updateplan.html', {'form': form, 'plan': plan})

@login_required
def payment(request, id):
    payment = Payment.objects.select_related('plan_id').all()
    plan = Plan.objects.get(id=id)
    template = loader.get_template('blog/paymentform.html')
    context = {
    'payment' : payment,
    'plan' : plan,
    }
    return HttpResponse(template.render(context, request))

@login_required
def planresev(request, id):
    if request.method == 'POST':
        user_id = request.user.id  
        plan = get_object_or_404(Plan, id=id) 
        phone = request.POST.get('phone')
        mop = request.POST.get('mop')

        booking = Booking.objects.create(phone=phone, user_id=user_id, plan=plan, mop=mop)

        return HttpResponseRedirect(reverse('settlement', args=[booking.id]))   

    return render(request, 'blog/settlement.html', context={})
    
def paymentlist(request):
  payment = Payment.objects.all()
  template = loader.get_template('blog/paymentlist.html')
  context = {
    'payment' : payment,
  }
  return HttpResponse(template.render(context, request))

def reservationlist(request):
  booking = Booking.objects.all()
  template = loader.get_template('blog/reservationlist.html')
  context = {
    'booking' : booking,
  }
  return HttpResponse(template.render(context, request))

def settlement(request, id):
    booking = get_object_or_404(Booking, id=id)

    plan = booking.plan
    plan_name = plan.name
    plan_price = plan.price

    booking_mop = booking.mop
    total_years = 5

    total_price = plan_price * total_years

    if booking_mop == 'annually':
        total_price = plan_price / total_years
    elif booking_mop == 'semi_annually':
        total_price = plan_price / (total_years * 2)  
    elif booking_mop == 'quarterly':
        total_price = plan_price / (total_years * 4) 
    elif booking_mop == 'monthly':
        total_price = plan_price / (total_years * 12) 
    else:
        total_price = plan_price  

    
    context = {
        'booking': booking,
        'plan_name': plan_name,
        'plan_price': plan_price,
        'booking_mop': booking_mop,
        'total_price': total_price,
    }

    
    return render(request, 'blog/settlement.html', context)

def settle(request, id):
    if request.method == 'POST':
        booking = get_object_or_404(Booking, id=id) 
        total = request.POST.get('total')
        ref_num = request.POST.get('ref_num')
        amount = request.POST.get('amount')
        date = request.POST.get('date')

        payment = Payment.objects.create(total=total, booking=booking, ref_num=ref_num, amount=amount, date=date)

        return HttpResponseRedirect(reverse('plan',))   

    return render(request, 'blog/settlement.html', context={})


def update_status(request, payment_id):
    if request.method == 'POST':
        payment = get_object_or_404(Payment, pk=payment_id)

        new_status = request.POST.get('status')

        payment.status = new_status
        payment.save()
        return redirect('list')
    else:
        return HttpResponseBadRequest("Invalid request method")
    
def least(request):
  booking = Booking.objects.all()
  template = loader.get_template('blog/bookinghistory.html')
  context = {
    'booking' : booking,
  }
  return HttpResponse(template.render(context, request))

def userresdips(request):
    booking = Booking.objects.filter(user=request.user)
    template = loader.get_template('blog/bookinghistory.html')
    context = {
    'booking' : booking,
  }
    return HttpResponse(template.render(context, request))

class PlanListView(View):
    template_name = 'blog/reservation.html'

    def get(self, request, id=None):
        if id is not None:
            plan = get_object_or_404(Plan, pk=id)
            total_price = self.calculate_total_price(plan)

            if not total_price:
                return render(request, 'error.html', {'message': 'Plan details not found.'})

            return render(request, 'blog/reservation.html', total_price)

        plan = Plan.objects.all()
        return render(request, self.template_name, {'plan': plan})

    def calculate_total_price(self, plan):
        plan_price = plan.price  
        total_years = 5  

       
        total_price = plan_price * total_years

        
        annually = plan_price / total_years  
        semi_annually = plan_price / (total_years * 2)  
        quarterly = plan_price / (total_years * 4)  
        monthly = plan_price / (total_years * 12)  
        
        annually = round(annually, 2)
        semi_annually = round(semi_annually, 2)
        quarterly = round(quarterly, 2)
        monthly = round(monthly, 2)
        return {
            'plan': plan,
            'total_price': total_price,
            'annually': annually,
            'semi_annually': semi_annually, 
            'quarterly': quarterly,
            'monthly': monthly,
        }
    
class Boking(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    plan = models.ForeignKey(Plan, on_delete=models.CASCADE)
    mop = models.CharField(max_length=255, null=True)
    phone = models.IntegerField()

    STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('declined', 'Declined'),
    )
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')

    @property
    def total_price(self):
        # Calculate total price based on plan and mode of payment
        if self.mop == 'annually':
            return self.plan.price  # Total price for one year
        elif self.mop == 'semi_annually':
            return self.plan.price / 2  # Total price for six months
        elif self.mop == 'quarterly':
            return self.plan.price / 4  # Total price for three months
        elif self.mop == 'monthly':
            return self.plan.price / 12  # Total price for one month
        else:
            return self.plan.price  # Default to annual price if mode is unspecified

    def __str__(self):
        return f"{self.user.username} - {self.plan}"
def reports(request):
    total_reservations = Payment.objects.count()
    total_sale = Payment.objects.aggregate(total_sale=Sum('amount'))['total_sale'] or 0
    total_users = Payment.objects.values('booking_id').distinct().count()

    reports = Payment.objects.all()

    return render(request, 'blog/reports.html', {
        'reports': reports,
        'total_reservations': total_reservations,
        'total_sale': total_sale,
        'total_users': total_users
    })

def paymenthistory(request):
    payment = Payment.objects.all()
    template = loader.get_template('blog/userpayment.html')
    context = {
    'payment' : payment,
  }
    return HttpResponse(template.render(context, request))

def displaydate(request):
    selected_date = request.GET.get('selected_date')  # Assuming 'selected_date' is passed as a query parameter
    transactions = []

    if selected_date:
        # Filter payments by the selected date
        transactions = Payment.objects.filter(date=selected_date)

    # Render the HTML template
    context = {
        'selected_date': selected_date,
        'transactions': transactions,
    }
    return render(request, 'blog/transaction.html', context)

def generate_pdf(request):
    selected_date = request.GET.get('selected_date')
    transactions = Payment.objects.filter(date=selected_date) if selected_date else []

    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="transactions_{selected_date}.pdf"'

    # Create a PDF document
    doc = SimpleDocTemplate(response, pagesize=letter)
    elements = []

    # Define styles
    styles = getSampleStyleSheet()
    style_heading = styles['Heading1']
    style_body = styles['BodyText']

    # Add heading to the PDF
    elements.append(Paragraph(f'Transactions for {selected_date}', style_heading))
    elements.append(Paragraph('', style_body))  # Add empty paragraph for spacing

    # Add table of transactions
    if transactions:
        data = [['Transaction ID','Booking.user.username', 'Amount', 'Date']]
        for transaction in transactions:
            data.append([str(transaction.id), str(transaction.booking.user.username),str(transaction.amount), str(transaction.date)])

        table = Table(data)

        # Define table style
        table_style = TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),  # Header row background color
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),        # Header row text color
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),               # Center-align all cells
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),    # Header row font style
            ('BACKGROUND', (0, 1), (-1, -1), colors.white),     # Body row background color
            ('GRID', (0, 0), (-1, -1), 1, colors.black)          # Border grid color and width
        ])

        # Apply table style
        table.setStyle(table_style)

        # Add table to PDF elements
        elements.append(table)
    else:
        elements.append(Paragraph('No transactions found for the selected date.', style_body))

    # Build the PDF document
    doc.build(elements)

    return response