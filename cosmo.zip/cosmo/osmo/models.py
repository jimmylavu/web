from django.db import models
from django.contrib.auth.models import User
# Create your models here


class Plan(models.Model):
    img = models.ImageField(upload_to='images/', null=True)
    price =models.IntegerField()
    name  = models.CharField(max_length=255, null=True)
    description  = models.CharField(max_length=255, null=True)

    def __str__(self):
        return f"{self.name} {self.img}"
    
class Booking(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    plan = models.ForeignKey(Plan, on_delete=models.CASCADE)
    mop  = models.CharField(max_length=255, null=True)
    phone = models.IntegerField()

    def __str__(self):
        return f"{self.user.username} - {self.plan}"
     
class Payment(models.Model):
    date = models.DateField(null=True)
    booking = models.ForeignKey(Booking, on_delete=models.CASCADE)
    total = models.DecimalField(max_digits=10, decimal_places=2, null=True)
    ref_num = models.CharField(max_length=100, null=True)
    amount = models.IntegerField( null=True)
    timestamp = models.DateTimeField(auto_now_add=True, null=True)

    STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('declined', 'Declined'),
    )
    
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    def __str__(self):
        return f"Payment for {self.booking} - {self.total}"
    
    def __str__(self):
        return f"Transaction #{self.id} by {self.booking.user.username} on {self.timestamp}"

    
